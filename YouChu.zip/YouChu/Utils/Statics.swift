//
//  Statics.swift
//  YouChu
//
//  Created by 김현식 on 2021/05/19.
//

import Foundation

let baseUrl: String = "https://www.youchu.link/"
